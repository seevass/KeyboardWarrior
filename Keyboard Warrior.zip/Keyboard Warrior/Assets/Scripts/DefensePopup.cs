using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System.Text;
using UnityEngine.UI;


public class DefensePopup : MonoBehaviour
{
    public GameObject focusedFrame;
    public GameObject outOfFocusFrame;
    public GameObject typer;
    private Typer typerScript;
    public string wordToType;

    public TextMeshProUGUI defenseText;

    public Image circleTimer;

    private Coroutine defenseCoroutine;

    // Start is called before the first frame update
    void Start()
    {
        typerScript = typer.GetComponent<Typer>();
        gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if(typerScript.defensePopupWords.Last.Value == wordToType)
        {
            focusedFrame.SetActive(true);
            outOfFocusFrame.SetActive(false);
        } else
        {
            focusedFrame.SetActive(false);
            outOfFocusFrame.SetActive(true);
        }
    }

    public void GenerateWordToType()
    {
        wordToType = typerScript.availableWordList[Random.Range(0, typerScript.availableWordList.Count)];
        typerScript.availableWordList.Remove(wordToType);
        typerScript.usedWordList.Add(wordToType);

        defenseText.text = wordToType;
        typerScript.defensePopupWords.AddFirst(defenseText.text);
        defenseCoroutine = StartCoroutine(StartPopupTimer(typerScript.enemyScript.timeForATKtoHit));
    }

    public void SpecialGenerateWordToType()
    {
        TextAsset[] jsonFiles = typerScript.jsonFiles;
        Word words = JsonUtility.FromJson<Word>(jsonFiles[2].text);
        wordToType = words.words[Random.Range(0, words.words.Length)];
        typerScript.availableWordList.Remove(wordToType);
        typerScript.usedWordList.Add(wordToType);

        defenseText.text = wordToType;
        typerScript.defensePopupWords.AddFirst(defenseText.text);
        defenseCoroutine = StartCoroutine(StartPopupTimer(typerScript.enemyScript.specialTimeForATKtoHit));
    }

    public void ClearWordToType()
    {
        if (wordToType != null)
        {
            if (typerScript.IsDefenseWord(wordToType)) {
                typerScript.availableWordList.Add(wordToType);
            }
            typerScript.usedWordList.Remove(wordToType);
            defenseText.text = "";
            typerScript.defensePopupWords.RemoveLast();
            StopTimerCoroutine();
        }
    }

    public void ClearFailedWordToType()
    {
        if (wordToType != null)
        {
            if (typerScript.IsDefenseWord(wordToType))
            {
                typerScript.availableWordList.Add(wordToType);
            }
            typerScript.usedWordList.Remove(wordToType);
            defenseText.text = "";
            typerScript.defensePopupWords.RemoveLast();
            typerScript.enemyScript.DealDamage(typerScript.enemyScript.attackDamage);
            typerScript.enemyScript.RemovePopUp();
        }
    }

    public IEnumerator StartPopupTimer(int numberOfSeconds)
    {
        float startFillAmount = 1f;
        float targetFillAmount = 0f;
        float elapsedTime = 0f;

        while (elapsedTime < numberOfSeconds)
        {
            circleTimer.fillAmount = Mathf.Lerp(startFillAmount, targetFillAmount, elapsedTime / numberOfSeconds);
            elapsedTime += Time.deltaTime;
            yield return null;
        }

        // Ensure that the fillAmount is exactly the target value
        circleTimer.fillAmount = targetFillAmount;
        typerScript.enemyScript.RemovePopUp();
        typerScript.enemyScript.DealDamage(typerScript.enemyScript.attackDamage);

    }

    public void StopTimerCoroutine()
    {
        if (defenseCoroutine != null)
        {
            StopCoroutine(defenseCoroutine);
        }
    }
}
