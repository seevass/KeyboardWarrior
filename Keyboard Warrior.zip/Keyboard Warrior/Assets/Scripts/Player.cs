using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    //stats
    public int health = 100;
    public int startingHealth = 100;
    public int attack = 5;

    //condition
    private bool isAlive = true;

    public GameObject typer;
    private Typer typerScript;

    //animation
    private Animator anim;

    //healthbar
    [SerializeField]
    private GameObject healthBar;
    private HealthBar healthScript;

    // Start is called before the first frame update
    void Start()
    {
        
        if (GameManager.Instance.chapterNumber == 1)
        {
            health = startingHealth;
        } else
        {
            health = GameManager.Instance.playerHealth;
        }
        typerScript = typer.GetComponent<Typer>();
        anim = GetComponent<Animator>();


        healthScript = healthBar.GetComponent<HealthBar>();
        healthScript.currentHealth = (float)health;
        healthScript.totalHealth = (float)startingHealth;
    }

    private void Update()
    {
        CheckHealth();
    }



    public void TakeDamage(int damage)
    {
        Debug.Log("player hit");
        health -= damage;
        healthScript.currentHealth = (float)health;

        if (health < 0)
        {
            Debug.Log("player is slain");
            isAlive = false;
        }
    }

    public void DealDamage(int damage)
    {
        typerScript.enemyScript.TakeDamage(damage);
        Debug.Log("damage dealt");
        anim.SetTrigger("TrPlayerAttack");

    }

    private void CheckHealth()
    {
        if (health <= 0 && isAlive == true)
        {
            isAlive = false;
            typerScript.AddToChapter(" and the hero has been slain.");
            typerScript.LostGame();
        }
    }
}
