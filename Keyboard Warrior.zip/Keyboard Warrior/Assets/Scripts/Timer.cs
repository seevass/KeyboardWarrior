using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Timer: MonoBehaviour
{
    public TextMeshProUGUI timerText;
    private float startTime;
    private bool isRunning = false;
    public float elapsedTime;
    public string stopwatchTime;

    void Start()
    {
        // You can start the timer automatically if needed
        //StartTimer();
    }

    void Update()
    {
        if (isRunning)
        {
            elapsedTime = Time.time - startTime;

            // Calculate minutes and seconds
            int minutes = Mathf.FloorToInt(elapsedTime / 60f);
            int seconds = Mathf.FloorToInt(elapsedTime % 60f);

            // Update the timer text
            stopwatchTime = string.Format("{0:00}:{1:00}", minutes, seconds);
            timerText.text = stopwatchTime;
        }
    }

    public void StartTimer()
    {
        startTime = Time.time;
        isRunning = true;
    }

    public void StopTimer()
    {
        isRunning = false;
    }

    public void ResetTimer()
    {
        isRunning = false;
        timerText.text = "00:00";
    }
}

