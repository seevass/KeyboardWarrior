//Script responsible for all typing functionality. 
//Includes: attacking, defending, spellcasting*
//Parent for: Enemy, Player
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System.Text;
using System.Linq;

public class Typer : MonoBehaviour
{
    //text objects
    public TextMeshProUGUI wordOutput = null;
    public TextMeshProUGUI wordToType = null;
    public TextMeshProUGUI wordNext = null;
    public TextMeshProUGUI wordPrevious= null;
    //defense text objects
    public TextMeshProUGUI defenseWordOutput = null;
    public TextMeshProUGUI defenseWordToType = null;

    //attack text
    private string typingText = string.Empty;
    private string currentWord = string.Empty;
    private string nextWord = string.Empty;
    private string previousWord = string.Empty;

    //correctness colors
    public string correctColor = "#FFFFFFFF";
    public string wrongColor = "#3F3F3F";

    //word JSON variables
    public TextAsset[] jsonFiles;
    private Word words;
    public string[] currentWordList;

    //word probabilities
    public float easyWordProbability = 0.85f;
    public float mediumWordProbability = 0.1f;
    public float hardWordProbability = 0.05f;

    private float[] wordProbabilities;
    private float[] oldWordProbabilities;

    //accuracy
    public int correctWordsTyped = 0;
    public int wrongWordsTyped = 0;
    
    //timer and wpm
    public Timer timer;
    private bool timerStarted = false;
    public int roundedWPM;
    public TextMeshProUGUI wpmText = null;

    //defense variables
    private bool isDefense;
    public GameObject defenseTypeBubble;
    private List<string> defenseWordList = new List<string>{"defend", "dodge", "evade", "duck", "swerve", "sidestep", "jump", "avoid","dive"};
    public List<string> usedWordList = new List<string>();
    public List<string> availableWordList = new List<string>();

    //defense text
    public string defenseTypingText = string.Empty;
    public LinkedList<string> defensePopupWords = new LinkedList<string>();

    //player
    public GameObject player;
    public Player playerScript;
    public GameObject currentEnemy;
    public Enemy enemyScript;

    //coroutines
    public Coroutine defensePopupCoroutine;

    //chaptertext

    public TextMeshProUGUI chapterText = null;
    public TextMeshProUGUI chapterNumber = null;

    //game conditions

    public bool fightOver = false;
    public bool playerWin = false;

    void Start()
    {
        wordProbabilities = new float[] { easyWordProbability, mediumWordProbability, hardWordProbability };
        words = JsonUtility.FromJson<Word>(jsonFiles[0].text);
        currentWordList = words.words;

        InitializeWords();

        timer = GetComponent<Timer>();

        defenseTypeBubble.SetActive(false);
        isDefense = false;
        defenseWordOutput.text = "";

        //defense word list generation
        availableWordList = new List<string>(defenseWordList);

        enemyScript = currentEnemy.GetComponent<Enemy>();
        playerScript = player.GetComponent<Player>();

        chapterNumber.text = "Chapter " + GameManager.Instance.chapterNumber.ToString();
    }

    // Update is called once per frame
    void Update()
    {
        CheckInput();
        UpdateWordOutput();

    }

    private void CheckInput()
    {
        if (Input.anyKeyDown)
        {
            string keysPressed = Input.inputString;

            if (Input.GetKeyDown(KeyCode.Space))
            {
                SubmitString();
            }
            if (Input.GetKeyDown(KeyCode.Tab))
            {
                ChangeStance();
            }
            if (keysPressed.Length == 1 && IsPrintableCharacter(keysPressed[0]))
            {
                if (!timerStarted)
                {
                    timer.StartTimer();
                    timerStarted = true;

                    enemyScript.StartEnemyCoroutine(enemyScript.attackInterval[Random.Range(0, enemyScript.attackInterval.Length)]);
                    StartCoroutine(enemyScript.SpecialAttackIncrement(enemyScript.specialAttackIncrementSeconds));
                }
                EnterLetter(keysPressed);
            }
            else if (Input.GetKeyDown(KeyCode.Backspace))
            {
                DeleteLetter();
            }
        }
    }

    private void InitializeWords()
    {
        currentWord = GenerateRandomWord();
        wordToType.text = currentWord;

        nextWord = GenerateRandomWord();
        wordNext.text = nextWord;

        wordPrevious.text = "";
    }

    private void NewWord()
    {
        previousWord = currentWord;
        wordPrevious.text = previousWord;

        currentWord = nextWord;
        wordToType.text = currentWord;

        nextWord = GenerateRandomWord();
        wordNext.text = nextWord;
    }

    private string GenerateRandomWord()
    {
        System.Random random = new System.Random();
        float total = 0;

        foreach (float probability in wordProbabilities)
        {
            total += probability;
        }

        float randomPoint = (float)random.NextDouble() * total;

        for (int i = 0; i <wordProbabilities.Length; i++)
        {
            if (randomPoint < wordProbabilities[i])
            {
                currentWordList = JsonUtility.FromJson<Word>(jsonFiles[i].text).words;
                return currentWordList[Random.Range(0, currentWordList.Length)];
            } else
            {
                randomPoint -= wordProbabilities[i];
            }
        }
        currentWordList = JsonUtility.FromJson<Word>(jsonFiles[wordProbabilities.Length - 1].text).words;
        return currentWordList[Random.Range(0, currentWordList.Length)];
    }

    private void SubmitString()
    {
        if (!isDefense)
        {
            if (typingText.Length == 0)
            {
                return;
            }
            if (typingText == currentWord)
            {
                correctWordsTyped++;
                UpdateWordPerMinute();
                playerScript.DealDamage(playerScript.attack);
                AddToChapter(" strikes, ");
            } 
            else
            {
                wrongWordsTyped++;
                enemyScript.IncreaseSpecialAtkMeter(15);
                AddToChapter(" misses, ");
            }

            typingText = "";
            NewWord();
        } else
        {
            if (defenseTypingText.Length == 0)
            {
                return;
            }
            if (defensePopupWords.Count > 0)
            {
                if (defenseTypingText == defensePopupWords.Last.Value)
                {
                    AddToChapter(" " + defenseTypingText + "s, ");
                    currentEnemy.GetComponent<Enemy>().RemovePopUp();
                    defenseTypingText = "";
                    defenseWordOutput.text = "";

                    correctWordsTyped++;
                    UpdateWordPerMinute();
                    if (usedWordList.Count == 0)
                    {
                        ChangeStance();
                    }
                 } else
                {
                    wrongWordsTyped++;
                    AddToChapter(" gets hit, ");
                }
            }
        }
    }
    private void EnterLetter(string keysPressed)
    {
        if (!isDefense)
        {
            typingText = typingText + keysPressed;
        } else
        {
            defenseTypingText = defenseTypingText + keysPressed;
        }
    }

    private void DeleteLetter()
    {
        if (!isDefense)
        {
            if (typingText.Length > 0)
            {
                typingText = typingText.Remove(typingText.Length - 1);
            }

        } else
        {
            if (defenseTypingText.Length > 0)
            {
                defenseTypingText = defenseTypingText.Remove(defenseTypingText.Length - 1);
            }
        }
    }

    private bool IsPrintableCharacter(char character)
    {
        return char.IsLetterOrDigit(character) || char.IsPunctuation(character) || char.IsSymbol(character);
    }

    private void UpdateWordOutput()
    {
        if (!isDefense)
        {
            StringBuilder coloredText = new StringBuilder();

            for (int i = 0; i < typingText.Length; i++)
            {
                char typedChar = typingText[i];
                char expectedChar = (i < currentWord.Length) ? currentWord[i] : '\0'; // Ensuring we don't go out of bounds

                if (typedChar == expectedChar)
                {
                    coloredText.Append("<color=" + correctColor + ">"); // White for correct characters
                }
                else
                {
                    coloredText.Append("<color=" + wrongColor + ">"); // Red for incorrect characters
                }

                coloredText.Append(typedChar);
                coloredText.Append("</color>");
            }

            wordOutput.text = coloredText.ToString();
        }
        else
        {
            if (defensePopupWords.Count > 0)
            {
                StringBuilder coloredText = new StringBuilder();
                for (int i = 0; i < defenseTypingText.Length; i++)
                {
                    char typedChar = defenseTypingText[i];
                    char expectedChar = (i < defensePopupWords.Last.Value.Length) ? defensePopupWords.Last.Value[i] : '\0'; // Ensuring we don't go out of bounds

                    if (typedChar == expectedChar)
                    {
                        coloredText.Append("<color=" + correctColor + ">"); // White for correct characters
                    }
                    else
                    {
                        coloredText.Append("<color=" + wrongColor + ">"); // Red for incorrect characters
                    }

                    coloredText.Append(typedChar);
                    coloredText.Append("</color>");
                }

                defenseWordOutput.text = coloredText.ToString();
            }
        }
    }

    private void UpdateWordPerMinute()
    {
        float wpm = (correctWordsTyped / timer.elapsedTime) * 60;
        roundedWPM = Mathf.RoundToInt(wpm);
        wpmText.text = roundedWPM.ToString();

    }

    private void ChangeStance()
    {
        isDefense = !isDefense;
        defenseTypeBubble.SetActive(isDefense);
        typingText = string.Empty;
        defenseTypingText = string.Empty;
    }

    public void AddToChapter(string text)
    {
        chapterText.text = chapterText.text + text;
    }

    private void CopyProbabilitiesToArray(float[] sourceArray, float[] destinationArray)
    {
        for (int i = 0; i < sourceArray.Length; i++)
        {
            destinationArray[i] = sourceArray[i];
        }
    }

    public bool IsDefenseWord(string word)
    {
        return defenseWordList.Contains(word);
    }

    public void WonGame()
    {
        fightOver = true;
        playerWin = true;
        GameManager.Instance.playerHealth = playerScript.health;
    }

    public void LostGame()
    {
        fightOver = true;
        playerWin = false;
    }

    private void UpdateChapterNumber()
{
    chapterNumber.text = "Chapter " + GameManager.Instance.chapterNumber.ToString();
}
}
