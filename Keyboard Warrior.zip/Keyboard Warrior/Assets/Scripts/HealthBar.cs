using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthBar : MonoBehaviour
{
    public Image healthBar;
    public float totalHealth = 100f;
    public float currentHealth = 100f;

    // Update is called once per frame
    void Update()
    {
        healthBar.fillAmount = currentHealth / totalHealth;
    }
}
