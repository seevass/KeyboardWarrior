using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;
using UnityEngine.EventSystems;

public class Menu : MonoBehaviour
{
    private Typer typerScript;
    [SerializeField]
    private GameObject typer;
    [SerializeField]
    private GameObject pauseMenu;
    [SerializeField]
    private GameObject gameEndMenu;
    [SerializeField]
    private GameObject hideAfterWinLose;

    private EventSystem m_EventSystems;

    [SerializeField]
    private GameObject pauseButton;
    [SerializeField]
    private GameObject continueButton;
    [SerializeField]
    private GameObject restartButton;
    [SerializeField]
    private GameObject winState;
    [SerializeField]
    private GameObject loseState;

    //text

    public TextMeshProUGUI wpm = null;
    public TextMeshProUGUI time = null;
    public TextMeshProUGUI fightResult = null;

    private bool endReached = false;

    public static bool isPaused = false;
    void Start()
    {
        typerScript = typer.GetComponent<Typer>();
        pauseMenu.SetActive(false);
        gameEndMenu.SetActive(false);
        m_EventSystems = EventSystem.current;
        winState.SetActive(false);
        loseState.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape) && typerScript.fightOver == false)
        {
            TogglePause();
        }
        if (typerScript.fightOver == true)
        {
            EndResults();
        }
    }

    public void TogglePause()
    {
        isPaused = !isPaused;
        typerScript.enabled = !isPaused;
        if (isPaused)
        {
            Time.timeScale = 0;
            pauseMenu.SetActive(true);
            m_EventSystems.SetSelectedGameObject(pauseButton);
        }
        else
        {
            Time.timeScale = 1;
            pauseMenu.SetActive(false);
        }
        
    }

    public void RestartGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        GameManager.Instance.ResetVariables();
        Time.timeScale = 1;
    }

    public void EndResults()
    {
        if (!endReached)
        {
            Time.timeScale = 0;
            if (typerScript.playerWin)
            {
                m_EventSystems.SetSelectedGameObject(continueButton);
                winState.SetActive(true);
            }
            else
            {
                m_EventSystems.SetSelectedGameObject(restartButton);
                loseState.SetActive(true);
            }
        }

        fightResult.text = (typerScript.playerWin) ? "Vicory" : "Defeat";
        endReached = true;
        gameEndMenu.SetActive(true);
        hideAfterWinLose.SetActive(false);
        wpm.text = "Words per min: " + typerScript.roundedWPM.ToString();
        time.text = "Time elapsed: " + typerScript.timer.stopwatchTime;
    }

    public void Continue()
    {

        Time.timeScale = 1;
        GameManager.Instance.playerHealth = typerScript.playerScript.health;
        GameManager.Instance.chapterNumber++;
        GameManager.Instance.wpm = typerScript.roundedWPM;
        SceneManager.LoadScene(sceneName: "Game");
    }

    public void MainMenu()
    {
        SceneManager.LoadScene(sceneName: "MainMenu");
        Time.timeScale = 1;
        GameManager.Instance.ResetVariables();
    }
}
