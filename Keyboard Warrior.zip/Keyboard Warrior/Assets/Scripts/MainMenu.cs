using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    private Animator mAnimator;
    [SerializeField]
    private GameObject bookAnimate;
    [SerializeField]
    private GameObject animateDisable;
    // Start is called before the first frame update
    void Start()
    {
        mAnimator = bookAnimate.GetComponent<Animator>();
        bookAnimate.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void StartGame()
    {
        animateDisable.SetActive(false);
        bookAnimate.SetActive(true);
        mAnimator.SetTrigger("GameOpen");
        Invoke("ChangeToGame", 4f);
    }

    private void ChangeToGame()
    {
        SceneManager.LoadScene(sceneName: "Game");
    }
}
