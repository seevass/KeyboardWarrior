using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{

    //stats
    public int health = 200;
    public int attackDamage = 10;
    public int[] attackInterval = { 5,6,7,8 };
    public int timeForATKtoHit = 10;
    public int specialTimeForATKtoHit = 20;
    public int specialAttackMeter = 0;
    private int specialAttackMax = 100;
    private int specialAttackIncrementValue = 5;
    public int specialAttackIncrementSeconds = 1;
    private int oldSpecialAttackIncrementValue;

    //condition
    private bool isAlive = true;

    public GameObject typer;
    private Typer typerScript;

    public List<GameObject> defensePopupList = new List<GameObject>();
    public List<GameObject> usedPopupList = new List<GameObject>();
    public List<GameObject> availablePopupList = new List<GameObject>();

    private GameObject currentPopUp;
    public LinkedList<GameObject> popupOrder = new LinkedList<GameObject>();

    public GameObject warningPopUp;


    private DefensePopup defenseScript;

    //anim
    private Animator anim;

    //healthbar
    [SerializeField]
    private GameObject healthBar;
    private HealthBar healthScript;

    //Coroutine
    private Coroutine defensePopupCoroutine;

    // Start is called before the first frame update
    void Start()
    {
        typerScript = typer.GetComponent<Typer>();
        anim = GetComponent<Animator>();

        healthScript = healthBar.GetComponent<HealthBar>();
        healthScript.currentHealth = (float)health;
        healthScript.totalHealth = (float)health;

        availablePopupList = new List<GameObject>(defensePopupList);

        warningPopUp.SetActive(false);

        oldSpecialAttackIncrementValue = specialAttackIncrementValue;
    }

    private void Update()
    {
        CheckSpecialAttack();
        CheckHealth();
    }

    public void StartEnemyCoroutine(float delay)
    {
        StartCoroutine(DelayedStartCoroutine(delay));
    }

    public void StopEnemyCoroutine()
    {
        StopCoroutine(defensePopupCoroutine);
    }
    IEnumerator DelayedStartCoroutine(float delay)
    {
        // Wait for the specified delay
        yield return new WaitForSeconds(delay);

        // Start the DynamicInvokeCoroutine after the delay
        specialAttackIncrementValue = oldSpecialAttackIncrementValue;
        defensePopupCoroutine = StartCoroutine(DynamicInvokeCoroutine());
    }
    //Coroutine so that attackInterval can be changed (future proof)
    public IEnumerator DynamicInvokeCoroutine()
    {
        while (true)
        {
            GenerateNewPopUp();
            yield return new WaitForSeconds(attackInterval[Random.Range(0, attackInterval.Length)]);

        }
    }

    public IEnumerator SpecialAttackIncrement(float delay)
    {
        while (true)
        {
            IncrementSpecialAtkMeter();
            yield return new WaitForSeconds(delay);
        }
    }

    public void IncreaseSpecialAtkMeter(int amount)
    {
        specialAttackMeter = specialAttackMeter + amount;
    }

    private void IncrementSpecialAtkMeter()
    {
        specialAttackMeter = specialAttackMeter + specialAttackIncrementValue;
    }


    private void CheckSpecialAttack()
    {
        if (specialAttackMeter > specialAttackMax * 0.70)
        {
            warningPopUp.SetActive(true);
        }
        if (specialAttackMeter >= specialAttackMax)
        {
            warningPopUp.SetActive(false);
            specialAttackMeter = 0;
            LaunchSpecialAttack();
        }
    }

    private void LaunchSpecialAttack()
    {
        ClearPopUps();
        SpecialAttackPopUps();
        SpecialAttackPopUps();
        SpecialAttackPopUps();

        oldSpecialAttackIncrementValue = specialAttackIncrementValue;
        specialAttackIncrementValue = 0;

        StopEnemyCoroutine();
        StartEnemyCoroutine(specialTimeForATKtoHit + 2);
        return;
    }

    public void GenerateNewPopUp()
    {
        if (availablePopupList.Count > 0)
        {
            currentPopUp = availablePopupList[Random.Range(0, availablePopupList.Count)];
            currentPopUp.SetActive(true);
            defenseScript = currentPopUp.GetComponent<DefensePopup>();
            defenseScript.GenerateWordToType();

            availablePopupList.Remove(currentPopUp);
            usedPopupList.Add(currentPopUp);
            popupOrder.AddFirst(currentPopUp);

        }
    }
    public void SpecialAttackPopUps()
    {
        if (availablePopupList.Count > 0)
        {
            currentPopUp = availablePopupList[Random.Range(0, availablePopupList.Count)];
            currentPopUp.SetActive(true);
            defenseScript = currentPopUp.GetComponent<DefensePopup>();
            defenseScript.SpecialGenerateWordToType();

            availablePopupList.Remove(currentPopUp);
            usedPopupList.Add(currentPopUp);
            popupOrder.AddFirst(currentPopUp);

        }
    }

    public void RemovePopUp()
    {
        if (popupOrder.Count > 0)
        {
            currentPopUp = popupOrder.Last.Value;
            popupOrder.RemoveLast();
            currentPopUp.GetComponent<DefensePopup>().ClearWordToType();
            availablePopupList.Add(currentPopUp);
            usedPopupList.Remove(currentPopUp);
            currentPopUp.SetActive(false);
        }
    }

    private void ClearPopUps()
    {
        RemovePopUp();
        RemovePopUp();
        RemovePopUp();
        RemovePopUp();
    }

    public void TakeDamage(int damage)
    {
        health = health - damage;
        healthScript.currentHealth = (float)health;

        anim.SetTrigger("TrEnemyHit");
        if (health < 0)
        {
            Debug.Log("enemy is slain");
            isAlive = false;
        }
    }

    public void DealDamage(int damage)
    {
        typerScript.playerScript.TakeDamage(damage);
        Debug.Log("damage to player dealt");
    }

    private void CheckHealth()
    {
        if (health <= 0 && isAlive == true)
        {
            isAlive = false;
            typerScript.AddToChapter(" and has slain the enemy!");
            typerScript.WonGame();
        }
    }

}
